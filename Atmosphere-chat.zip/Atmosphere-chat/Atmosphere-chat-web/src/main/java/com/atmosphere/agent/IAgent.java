package com.atmosphere.agent;

public class IAgent {

}
